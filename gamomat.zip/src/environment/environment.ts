export const env = {
    tilesPerReel: 4,
};